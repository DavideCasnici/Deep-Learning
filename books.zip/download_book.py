import requests
import wget as wget
from pathlib import Path


#url = input("write the url: \n")
#name = input("write the name of the file (no extension): \n")
#r = wget.download(url)
#Path(r).rename('books/'+name+'.txt')

#from os import walk

#filenames = next(walk("books/"), (None, None, []))[2]  # [] if no file
#print(len(filenames))
#final = ""
#for file in filenames:
#    with open("books/"+file, 'r') as text:
#        for line in text:
#            final += line

#with open("final.txt", 'x') as text:
#    text.write(final)
#print("finished")